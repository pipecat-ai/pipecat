import base64
import time
from abc import ABC, abstractmethod
from typing import Optional

from pydantic import BaseModel, Field

from ojin.entities.interaction_messages import (
    CancelInteractionInput,
    InteractionInput,
    InteractionInputMessage,
    InteractionResponseMessage,
)


class OjinAvatarMessage(BaseModel):
    """Base class for all Ojin Avatar messages.

    All messages exchanged with the Ojin Avatar backend inherit from this class.
    """

    def to_proxy_message(self) -> BaseModel:
        raise NotImplementedError


class OjinAvatarSessionReadyMessage(OjinAvatarMessage):
    """Message to start a new interaction with an Ojin Avatar.

    Contains the ID of the avatar to interact with.
    """


class StartInteractionMessage(OjinAvatarMessage):
    """Message to start a new interaction with an Ojin Avatar.

    Contains the ID of the avatar to interact with.
    """


class StartInteractionResponseMessage(OjinAvatarMessage):
    """Response message for a successful interaction start.

    Contains the unique ID assigned to the new interaction.
    """

    interaction_id: str


class OjinAvatarInteractionReadyMessage(OjinAvatarMessage):
    """Message indicating that an interaction is ready to begin.

    Contains the interaction ID and avatar ID.
    """

    interaction_id: str


class OjinAvatarInteractionResponseMessage(OjinAvatarMessage):
    """Response message containing video data from the avatar.

    Contains the interaction ID, avatar ID, and the video data as bytes.
    """

    interaction_id: str
    video_frame_bytes: bytes
    is_final_response: bool = False

    @classmethod
    def from_proxy_message(cls, proxy_message: InteractionResponseMessage):
        return cls(
            interaction_id=proxy_message.payload.interaction_id,
            video_frame_bytes=proxy_message.payload.payload,
            is_final_response=proxy_message.payload.is_final_response,
        )


class OjinAvatarCancelInteractionMessage(OjinAvatarMessage):
    """Message to cancel an interaction."""

    interaction_id: str

    def to_proxy_message(self) -> CancelInteractionInput:
        return CancelInteractionInput(
            interaction_id=self.interaction_id,
            timestamp=int(time.monotonic() * 1000),
        )


class OjinAvatarInteractionInputMessage(OjinAvatarMessage):
    """Message containing audio input for the avatar.

    Contains the audio data as bytes and a flag indicating if this is the last input.
    """

    audio_bytes: bytes
    interaction_id: str = Field(default="", init=True)
    start_frame_idx: int | None = Field(default=None, init=True)
    is_last_input: bool = Field(default=False, init=True)

    def to_proxy_message(self) -> BaseModel:
        params = None
        if self.start_frame_idx is not None:
            params = {
                "start_frame_idx": self.start_frame_idx,
            }
        payload = InteractionInput(
            interaction_id=self.interaction_id,
            payload_type="audio",
            payload=base64.b64encode(self.audio_bytes).decode("utf-8"),
            is_final_input=self.is_last_input,
            timestamp=int(time.monotonic() * 1000),
            params=params,
        )
        return InteractionInputMessage(
            payload=payload,
        )


class ErrorResponsePayload(BaseModel):
    """Response message informing the client there was an error.

    contains details about the error
    """

    error: str
    code: Optional[str] = None
    timestamp: Optional[int] = None


class ErrorResponseMessage(BaseModel):
    """Response message informing the client there was an error.

    contains details about the error
    """

    type: str
    payload: ErrorResponsePayload


class IOjinAvatarClient(ABC):
    """Interface for Ojin Avatar client communication.

    Defines the contract for sending and receiving messages to/from the Ojin Avatar
    client.
    """

    @abstractmethod
    async def connect(self) -> None:
        """Connects the client to the proxy."""

    @abstractmethod
    async def send_message(self, message: BaseModel) -> None:
        """Send a message to the server.

        Args:
           message: The message to send.

        """

    @abstractmethod
    async def receive_message(self) -> BaseModel:
        """Receive a message from the server

        Returns:
            The received message.

        """

    @abstractmethod
    async def close(self) -> None:
        """Close the client."""
