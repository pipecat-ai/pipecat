import VoiceAssistant from '../components/VoiceAssistant'

export default function Home() {
  return <VoiceAssistant />
}